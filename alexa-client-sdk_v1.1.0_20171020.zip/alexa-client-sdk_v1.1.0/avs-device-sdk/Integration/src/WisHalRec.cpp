#include "WisHalRec.h"

void WisHalRec::fill_default_params(struct audio_config_params *params, int rec_session) {
    memset(params,0, sizeof(struct audio_config_params));
    params->input_device = AUDIO_DEVICE_IN_BUILTIN_MIC;
    params->config.format = AUDIO_FORMAT_PCM_16_BIT;
    params->channels = 2;
    params->flags = (audio_input_flags_t)AUDIO_INPUT_FLAG_NONE;
    params->config.sample_rate = 48000;
    //params->source = 1;
    params->source = AUDIO_SOURCE_MIC;
    params->record_length = 8; //sec
    params->record_delay = 0; //sec

    if (rec_session == 1) {
        params->handle = 0x999;
    } else if (rec_session == 2) {
        params->handle = 0x998;
    } else if (rec_session == 3) {
        params->handle = 0x997;
    } else if (rec_session == 4) {
        params->handle = 0x996;
    }
}

bool WisHalRec::initialRecorder(){
  log_file = stdout;

  const  char *mod_name = "audio.primary";
  struct listnode param_list;

  list_init(&param_list);
  fill_default_params(&params,1);
  params.input_device =2;
  //params.config.format = 1;
  params.config.format = AUDIO_FORMAT_PCM_16_BIT;
  params.config.sample_rate = 16000;
  params.channels =1;
  params.record_length = 15;

  //struct audio_config_params* params = (struct audio_config_params*) params;
  //qahw_module_handle_t *qahw_mod_handle = params.qahw_mod_handle;
  params.config.channel_mask = AUDIO_CHANNEL_IN_MONO;

  qahw_mod_handle = qahw_load_module(mod_name);
  if(qahw_mod_handle == NULL) {
    fprintf(log_file, " qahw_load_module failed");
    return false;
  }
  return true;
}
