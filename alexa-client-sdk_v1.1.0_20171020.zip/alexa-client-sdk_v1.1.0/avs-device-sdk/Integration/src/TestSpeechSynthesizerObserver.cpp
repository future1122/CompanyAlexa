/*
 * TestSpeechSynthesizerObserver.cpp
 *
 * Copyright 2017 Amazon.com, Inc. or its affiliates. All Rights Reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License").
 * You may not use this file except in compliance with the License.
 * A copy of the License is located at
 *
 *     http://aws.amazon.com/apache2.0/
 *
 * or in the "license" file accompanying this file. This file is distributed
 * on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
 * express or implied. See the License for the specific language governing
 * permissions and limitations under the License.
 */
#include "Integration/TestSpeechSynthesizerObserver.h"

namespace alexaClientSDK {
namespace integration {
namespace test {

using avsCommon::sdkInterfaces::SpeechSynthesizerObserver;

TestSpeechSynthesizerObserver::TestSpeechSynthesizerObserver():
        m_state(SpeechSynthesizerObserver::SpeechSynthesizerState::FINISHED) {
}

// King add
void TestSpeechSynthesizerObserver::setStatusObserver(std::shared_ptr<avsCommon::sdkInterfaces::WisStatusChangedInterface> wisStatusChanged){
    m_wisStatusChanged = wisStatusChanged;
}
// King end

void TestSpeechSynthesizerObserver::onStateChanged(SpeechSynthesizerObserver::SpeechSynthesizerState state) {
    std::unique_lock<std::mutex> lock(m_mutex);
    printf("TestSpeechSynthesizerObserver::onStateChanged  currentSpeechSynthesizerState: %d, newState = %d\n", m_state, state);  // King add
    m_state = state;
    // King add
    if(m_wisStatusChanged){
        m_wisStatusChanged->onSpeechSynthesizerObserverStateChanged(m_state);
    }
    // King end
    m_queue.push_back(state);
    m_wakeTrigger.notify_all();
}

bool TestSpeechSynthesizerObserver::checkState(
    const SpeechSynthesizerObserver::SpeechSynthesizerState expectedState,
    const std::chrono::seconds duration) {
    // Pull the front of the state queue
    SpeechSynthesizerObserver::SpeechSynthesizerState hold = waitForNext(duration);
    return hold == expectedState;
}

SpeechSynthesizerObserver::SpeechSynthesizerState TestSpeechSynthesizerObserver::waitForNext(
    const std::chrono::seconds duration, bool clearQueue) {  // King update

	// King add
    if(clearQueue){
       m_queue.clear();
    }

    SpeechSynthesizerObserver::SpeechSynthesizerState ret;
    std::unique_lock<std::mutex> lock(m_mutex);
    if (!m_wakeTrigger.wait_for(lock, duration, [this]() { return !m_queue.empty(); })) {
        //Bob add
    std::cout << "TestSpeechSynthesizerObserver::waitForNext------state: " << std::endl;
        return m_state;
    }
    ret = m_queue.front();
    m_queue.pop_front();

    //Bob add
    std::cout << "TestSpeechSynthesizerObserver::waitForNext------finished" << std::endl;

    return ret;
}

SpeechSynthesizerObserver::SpeechSynthesizerState TestSpeechSynthesizerObserver::getCurrentState() {
    return m_state;
}

}  // namespace test
}  // namespace integration
}  // namespace alexaClientSDK
