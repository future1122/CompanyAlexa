#include <thread>
#include <iostream>
#include <getopt.h>
#include <stdio.h>
#include <string.h>
#include <time.h>
#include <pthread.h>
#include <stdlib.h>
#include <unistd.h>
#include <cutils/list.h>
#include <signal.h>
#include <errno.h>
#include "qahw_api.h"
#include "qahw_defs.h"

//#define nullptr NULL
#define LATENCY_NODE "/sys/kernel/debug/audio_in_latency_measurement_node"
#define LATENCY_NODE_INIT_STR "1"

#define ID_RIFF 0x46464952
#define ID_WAVE 0x45564157
#define ID_FMT  0x20746d66
#define ID_DATA 0x61746164

#define FORMAT_PCM 1

struct wav_header {
    uint32_t riff_id;
    uint32_t riff_sz;
    uint32_t riff_fmt;
    uint32_t fmt_id;
    uint32_t fmt_sz;
    uint16_t audio_format;
    uint16_t num_channels;
    uint32_t sample_rate;
    uint32_t byte_rate;       // sample_rate * num_channels * bps / 8
    uint16_t block_align;     // num_channels * bps / 8
    uint16_t bits_per_sample;
    uint32_t data_id;
    uint32_t data_sz;
};

struct audio_config_params {
    qahw_module_handle_t *qahw_mod_handle;
    audio_io_handle_t handle;
    audio_devices_t input_device;
    audio_input_flags_t flags;
    audio_config_t config;
    audio_source_t source;
    int channels;
    double record_delay;
    double record_length;
    char profile[50];
};

class WisHalRec {
private:
    void fill_default_params(struct audio_config_params *params, int rec_session);
public:
    bool initialRecorder();

    struct audio_config_params params;
    qahw_module_handle_t *qahw_mod_handle;
    FILE * log_file;
};
