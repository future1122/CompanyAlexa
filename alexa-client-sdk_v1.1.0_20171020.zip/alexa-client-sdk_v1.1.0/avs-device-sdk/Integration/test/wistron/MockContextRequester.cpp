#include "MockContextRequester.h"


std::shared_ptr<MockContextRequester> MockContextRequester::create
        (std::shared_ptr<ContextManager> contextManager) {
    auto result = std::make_shared<MockContextRequester>(contextManager);
    return result;
}

MockContextRequester::MockContextRequester(std::shared_ptr<ContextManager> contextManager):
        m_contextManager{contextManager},
        m_contextAvailable{false},
        m_contextFailure{false} {
}

MockContextRequester::~MockContextRequester() {
}

void MockContextRequester::onContextAvailable(const std::string& context) {
    std::unique_lock<std::mutex> lock(m_mutexSuccess);
    m_context = context;
    m_contextAvailable = true;
    m_wakeTriggerSuccess.notify_one();
    printf("--> King MockContextRequester::onContextAvailable m_context is: %s\n\n", m_context.c_str());
}

void MockContextRequester::onContextFailure(const ContextRequestError error) {
    printf("--> King MockContextRequester::onContextFailure\n");
    std::unique_lock<std::mutex> lock(m_mutexFailure);
    m_contextFailure = true;
    m_wakeTriggerFailure.notify_one();
}

bool MockContextRequester::waitForContext(const std::chrono::milliseconds duration) {
    m_contextAvailable = false;
    m_contextFailure = false;
    std::unique_lock<std::mutex> lock(m_mutexSuccess);
    if (!m_wakeTriggerSuccess.wait_for(lock, duration, [this]() { return (m_contextAvailable || m_contextFailure ); }))
    {
        return false;
    }
    return true;
}

bool MockContextRequester::waitForFailure(const std::chrono::milliseconds duration) {
    std::unique_lock<std::mutex> lock(m_mutexFailure);
    if (!m_wakeTriggerFailure.wait_for(lock, duration, [this]() { return (m_contextAvailable || m_contextFailure ); }))
    {
        return false;
    }
    return true;
}

std::string& MockContextRequester::getContextString() {
    return m_context;
}
