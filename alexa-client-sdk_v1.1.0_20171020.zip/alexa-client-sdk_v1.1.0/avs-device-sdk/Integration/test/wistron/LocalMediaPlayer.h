#include <algorithm>
#include <chrono>
#include <condition_variable>
#include <fstream>
#include <memory>
#include <mutex>
#include <thread>
#include <gmock/gmock.h>
#include <gtest/gtest.h>
#include <AVSCommon/Utils/Logger/Logger.h>
#include <AVSCommon/Utils/Memory/Memory.h>

#ifdef GSTREAMER_MEDIA_PLAYER
#include "MediaPlayer/MediaPlayer.h"
#else
#include "Integration/TestMediaPlayer.h"
#endif

#include "MockPlayerObserver.h"
#include "MockAttachmentReader.h"

#include "WisDefineResources.h"

class LocalMediaPlayer {
  private:
      std::string m_audioFilePath;
  public:
      void SetUp();

      /**
       * Sets the audio source to play.
       *
       */
      void setMediaPlayerSource(
              std::string audioFilePath=APP_ROOT_FOLDER + "dong.mp3",
              int iterations = 1,
              std::vector<size_t> receiveSizes = {std::numeric_limits<size_t>::max()});

      void setIStreamSource(std::string audioFilePath= APP_ROOT_FOLDER + "dong.mp3", bool repeat = false);

      std::string getAudioFilePath();

      /// An instance of the @c MediaPlayer
      std::shared_ptr<MediaPlayer> m_mediaPlayer;

      /// An observer to whom the playback started and finished notifications need to be sent.
      std::shared_ptr<MockPlayerObserver> m_playerObserver;
};
