#include <stdio.h>
#include <string>
#include <iostream>
#include <sstream>

#include "WisCommon.h"

class WisVolumeControl {
private:
    int readVolumeValueFromFile();
    void getProductVolume();
    bool getVolumeMute(std::string value);
    int getVolumeValue(std::string value);

    WisCommon vcWisCommon;
public:
    void sleep_ms(unsigned int secs);
    void setVolume(std::string value);
    void adjustVolume(std::string value);
    void setMuteOrUnmute(std::string value);
};
