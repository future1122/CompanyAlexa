#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <string>

class WisFM {
public:
  void enable(void main_ps_name_callback(int , char *));
  void disable();
  void search(void main_searchex_callback(int ));
  void setFrequency(int frequency);
  int getVolume();
  void setVolume(std::string volume);
  bool isFMOpened = false;
  bool mLastFMOpened = false;
  int  mLastFMFrequency;

private:

};
