#include "MockStateProvider.h"




std::shared_ptr<MockStateProvider> MockStateProvider::create
        (std::shared_ptr<ContextManager> contextManager, const NamespaceAndName& stateProviderName,
        const std::string& state, const StateRefreshPolicy& refreshPolicy, const std::chrono::milliseconds delayTime) {
    auto result = std::make_shared<MockStateProvider>(contextManager, stateProviderName, state,
            refreshPolicy, delayTime);
    return result;
}

MockStateProvider::MockStateProvider(std::shared_ptr<ContextManager> contextManager,
            const NamespaceAndName& stateProviderName, const std::string& state,
            const StateRefreshPolicy& refreshPolicy, const std::chrono::milliseconds delayTime):
        m_contextManager{contextManager},
        m_namespaceAndName{stateProviderName},
        m_state{state},
        m_refreshPolicy{refreshPolicy},
        m_stateRequestToken{0},
        m_delayTime{delayTime},
        m_provideState{false},
        m_stateProviderShutdown{false} {
            m_doProvideThread = std::thread(&MockStateProvider::doProvideState, this);
}

MockStateProvider::~MockStateProvider() {
    std::unique_lock<std::mutex> lock(m_providerMutex);
    m_stateProviderShutdown = true;
    m_providerWakeTrigger.notify_one();
    lock.unlock();
    if (m_doProvideThread.joinable()) {
        m_doProvideThread.join();
    }
}

void MockStateProvider::provideState(unsigned int stateRequestToken) {
    m_stateRequestToken = stateRequestToken;
    std::lock_guard<std::mutex> lock(m_providerMutex);
    m_provideState = true;
    m_providerWakeTrigger.notify_one();
}

void MockStateProvider::doProvideState() {
    while (true) {
        std::unique_lock<std::mutex> lock(m_providerMutex);
        m_providerWakeTrigger.wait(lock, [this]() { return (m_provideState || m_stateProviderShutdown); });
        if (m_stateProviderShutdown) {
            lock.unlock();
            return;
        }
        std::this_thread::sleep_for(m_delayTime);
        if(SetStateResult::SUCCESS == m_contextManager->setState(m_namespaceAndName, m_state, m_refreshPolicy,
                m_stateRequestToken)){
            m_provideState = false;  
        }
        lock.unlock();
    }
}

unsigned int MockStateProvider::getCurrentstateRequestToken() {
    return m_stateRequestToken;
}
