#include "WisDeviceScanFun.h"
#include <thread>
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<errno.h>
#include<sys/types.h>
#include<sys/socket.h>
#include<netinet/in.h>
#include<arpa/inet.h>
#include<unistd.h>

int WisDeviceScanFun::receiveCommand(){
  // 绑定地址
  struct sockaddr_in addrto;
  memset(&addrto,0,sizeof(addrto));
  addrto.sin_family = AF_INET;
  addrto.sin_addr.s_addr = htonl(INADDR_ANY);
  addrto.sin_port = htons(6000);

  // 广播地址
  struct sockaddr_in from;
  memset(&from,0,sizeof(from));
  from.sin_family = AF_INET;
  from.sin_addr.s_addr = htonl(INADDR_ANY);
  from.sin_port = htons(6000);

  int sock = -1;
  if ((sock = socket(AF_INET, SOCK_DGRAM, 0)) == -1) {
      perror("socket error");
      exit(-1);
  }

  int opt = 1;
  //设置该套接字为广播类型，
  int nb = 0;
  nb = setsockopt(sock, SOL_SOCKET, SO_BROADCAST, (char *)&opt, sizeof(opt));
  if(nb == -1) {
      printf("set socket error...");
      exit(-1);
  }

  if(bind(sock,(struct sockaddr *)&(addrto), sizeof(struct sockaddr_in)) == -1) {
      printf("bind error...");
      exit(-1);
  }

  int len = sizeof(struct sockaddr_in);
  char receivedCmd[1024] = {0};

  while(1) {
      printf("\t%s: waiting for new command...\n", APP_TAG.c_str());
      memset(receivedCmd,0x00,1024);
      //从广播地址接受消息
      int ret=recvfrom(sock, receivedCmd, 1024, 0, (struct sockaddr*)&from,(socklen_t*)&len);
      mSenderIPAddress = inet_ntoa(from.sin_addr);
      printf("receive from %s\n",mSenderIPAddress.c_str());
      if(ret<=0) {
          printf("\t%s: read error...\n", APP_TAG.c_str());
          continue;
      } else {
          if (strlen(receivedCmd) <= 0) {
              continue;
          }

          if (enableSoundWhenReceivedPhoneCmd) {
             playWarnSound();
          } else {
             pthread_t lightLEDThread;
             pthread_create(&lightLEDThread, NULL, lightLEDWhenReceivedPhoneCmd,NULL);
          }
          printf("\t%s: Run action with command...%s\n", APP_TAG.c_str(), receivedCmd);

          char *p = strtok(receivedCmd, ":");
          if (strcmp(p, CMD_PLAY_LOCAL_MUSIC) == 0) {
            bool isPlayingMusic = false;
            if (m_localMediaPlayer.m_mediaPlayer != nullptr && m_localMediaPlayer.m_mediaPlayer->getOffsetInMilliseconds() != -1) {
              if (m_localMediaPlayer.getAudioFilePath() == m_LocalMusicPath) {
                printf("\t%s: playing currently...\n", APP_TAG.c_str());
                isPlayingMusic = true;
              }
            }
            if (isPlayingMusic) {
              printf("\t%s: stop music...\n", APP_TAG.c_str());
              if (!enableSoundWhenReceivedPhoneCmd) {
                  m_localMediaPlayer.m_mediaPlayer->stop();
                  printf("\t%s: stop music done...\n", APP_TAG.c_str());
              }
            }else{
              printf("\t%s: play music start...\n", APP_TAG.c_str());
              pthread_t playMusicThread;
              int playMusicThreadError = pthread_create(&playMusicThread, NULL, playMusic,NULL);
              printf("\t%s: playMusicThreadError = %d\n", APP_TAG.c_str(), playMusicThreadError);
            }
          }
      }
  }
  close(sock);
  return 0;
}

void WisDeviceScanFun::start(){
  std::thread receiveCommandThread(&WisDeviceScanFun::receiveCommand,this);//创建一个分支线程，回调到myThread函数里
  receiveCommandThread.join();
}
