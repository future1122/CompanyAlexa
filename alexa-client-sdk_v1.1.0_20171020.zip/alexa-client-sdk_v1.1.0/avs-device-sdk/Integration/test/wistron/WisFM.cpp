#include "WisFM.h"
#include "fmapi.h"
#include "fmcommon.h"
#include <iostream>

void WisFM::enable(void main_ps_name_callback(int , char *)){
  if (!isFMOpened) {
    printf("%s\n", "FM enable");
    fm_config_data cfg_data ={
      .band = FM_RX_US_EUROPE,
      .emphasis = FM_RX_EMP75,
      .spacing = FM_RX_SPACE_50KHZ,
      .rds_system = FM_RX_RDS_SYSTEM,
      .bandlimits = {
        .lower_limit = 87500,
        .upper_limit = 108000
      }
    };

    printf("%s\n","fm_enable(cfg_data, main_ps_name_callback)" );
    fm_enable(cfg_data, main_ps_name_callback);
    isFMOpened = true;
  }
}

void WisFM::disable(){
  printf("%s\n", "FM disable");
  fm_disable();
  isFMOpened = false;
}

void WisFM::search(void main_searchex_callback(int )){
  printf("%s\n", "FM search station");
  fm_searchlistex(main_searchex_callback);
}

void WisFM::setFrequency(int frequency){
  printf("%s\n", "FM set frequency");
  mLastFMFrequency = frequency;
  fm_setfreq(frequency);
}

int WisFM::getVolume(){
  printf("%s\n", "FM get volume");
  pid_t status;
  status = system("volume_control get_fm");
  int current_volume = WEXITSTATUS(status);
  printf("current voluem value: %d\n", current_volume);
  return current_volume;
}

void WisFM::setVolume(std::string volume){
  printf("%s: %s\n", "FM set volume", volume.c_str());
  std::string command = "volume_control set_fm "+volume;
  std::cout << "set fm volume command: " << command << std::endl;
  system(command.c_str());
  command ="volume_control get_fm";
  system(command.c_str());
}
