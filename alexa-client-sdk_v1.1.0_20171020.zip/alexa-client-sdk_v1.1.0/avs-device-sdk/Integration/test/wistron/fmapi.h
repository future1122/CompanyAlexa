#ifndef __FM_API_H__
#define __FM_API_H__
#include "fmcommon.h"

#if __cplusplus
extern "C" {
#endif

// Seek parameters
typedef enum
{
  FM_SEEK_UP,
  FM_SEEK_DOWN,
  FM_SEEK_MAX
}fm_seek_direction;

// Scan parameters
typedef enum
{
  FM_SCAN_UP,
  FM_SCAN_DOWN,
  FM_SCAN_MAX
}fm_scan_direction;

typedef void (*search_callback)(int station_num, int *station_list);
typedef void (*searchex_callback)(int search_freq);
typedef void (*pa_name_callback)(int ps_name_len, char *ps_name);

void fm_enable(fm_config_data cfg_data, pa_name_callback ps_name_callback_ptr);
void fm_disable(void);
void fm_setfreq(uint32 ulfreq);
void fm_getcurrentconfig(fm_station_params_available *config);
void fm_seek(fm_seek_direction seek_dir);
void fm_scan(fm_scan_direction scan_dir);
void fm_searchlist(search_callback search_callback_ptr);
void fm_searchlistex(searchex_callback searchex_callback_ptr);
void fm_cancelsearch(void);
void fm_mute(mute_type mutemode);

#if __cplusplus
}  // extern "C"
#endif

#endif // __FM_API_H__
