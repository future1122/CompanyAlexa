#include "WisAVS.h"
#include "WisCommon.h"

/**
* save the product data(productId,dsn,codeverifier) to productdata.txt file
*/
void WisAVS::writeProductDataToFile(std::string& productId,std::string& dsn,std::string& verifier){
   std::ofstream fout(STORE_ROOT_FOLDER + "productdata.txt");
   fout<< productId << ":" << dsn << ":" << verifier;
   fout.close();
   std::cout << STORE_ROOT_FOLDER << "productdata.txt file is done" << std::endl;
}

/**
 * write the refersh token and client to refreshToken.json file
 * @param refreshToken refersh token from AVS
 * @param clientId     client ID
 */
void WisAVS::writeTokenToFile(std::string& refreshToken,std::string& clientId){
  std::ofstream fout(STORE_ROOT_FOLDER + "refreshtoken.json");
  fout<<"{" << "\n";
  fout<<"\"authDelegate\":{" << "\n";
  fout<<"\"refreshToken\":\"" << refreshToken << "\",\n";
  fout<<"\"clientId\":\""<< clientId << "\",\n";
  fout<<"\"clientSecret\":\""<<"a0d2172c775ed97b7be4980b8485b2ab94bb7f47654759fea7d1510da0743242\"," << "\n";
  fout<<"\"deviceSerialNumber\":\""<<"123456\"," << "\n";
  fout<<"\"deviceTypeId\":\""<<"my_device\"" << "\n";
  fout<<"}," << "\n";
  fout<<"\"alertsCapabilityAgent\":{" << "\n";
  fout<<"\"databaseFilePath\":\"" << APP_ROOT_FOLDER << "inputs/alerts.db" << "\",\n";
  fout<<"\"alarmSoundFilePath\":\"" << APP_ROOT_FOLDER << "inputs/alarm_normal.mp3" << "\",\n";
  fout<<"\"alarmShortSoundFilePath\":\"" << APP_ROOT_FOLDER << "inputs/alarm_short.wav" << "\",\n";
  fout<<"\"timerSoundFilePath\":\"" << APP_ROOT_FOLDER << "inputs/timer_normal.mp3" << "\",\n";
  fout<<"\"timerShortSoundFilePath\":\"" << APP_ROOT_FOLDER << "inputs/timer_short.wav" << "\"\n";
  fout<<"}," << "\n";
  fout<<"\"settings\":{" << "\n";
  fout<<"\"databaseFilePath\":\"" << APP_ROOT_FOLDER << "inputs/settings.db" << "\",\n";
  fout<<"\"defaultAVSClientSettings\":{" << "\n";
  fout<<"\"locale\":\"" << "en-US" << "\",\n";
  fout<<"}" << "\n";
  fout<<"}," << "\n";
  fout<<"\"certifiedSender\":{" << "\n";
  fout<<"\"databaseFilePath\":\"" << APP_ROOT_FOLDER << "inputs/certifiedSender.db" << "\",\n";
  fout<<"}" << "\n";
  fout<<"}" << "\n";
  fout.close();
}

/**
 * handle LWA response from AVS
 * @param code     response code
 * @param body     response body
 * @param clientId client id
 */
void WisAVS::handleLwaResponse1(long code, const std::string& body,std::string& clientId) {
   rapidjson::Document document;
   if (document.Parse(body.c_str()).HasParseError()) {
      ACSDK_ERROR(LX("handleLwaResponseFailed")
            .d("reason", "parseJsonFailed")
            .d("position", document.GetErrorOffset())
            .d("error", GetParseError_En(document.GetParseError())));
      return;
   }

   if (HttpPostInterface::HTTP_RESPONSE_CODE_SUCCESS_OK == code) {
      std::string authToken;
      std::string refreshToken;
      uint64_t expiresInSeconds = 0;

      auto authTokenIterator = document.FindMember(JSON_KEY_ACCESS_TOKEN.c_str());
      if (authTokenIterator != document.MemberEnd() && authTokenIterator->value.IsString()) {
         authToken = authTokenIterator->value.GetString();
      }

      auto refreshTokenIterator = document.FindMember(JSON_KEY_REFRESH_TOKEN.c_str());
      if (refreshTokenIterator != document.MemberEnd() && refreshTokenIterator->value.IsString()) {
         refreshToken = refreshTokenIterator->value.GetString();
      }

      auto expiresInIterator = document.FindMember(JSON_KEY_EXPIRES_IN.c_str());
      if (expiresInIterator != document.MemberEnd() && expiresInIterator->value.IsUint64()) {
         expiresInSeconds = expiresInIterator->value.GetUint64();
      }

      if (authToken.empty() || refreshToken.empty() || expiresInSeconds == 0) {
        ACSDK_ERROR(LX("handleLwaResponseFailed")
                .d("authTokenEmpty", authToken.empty())
                .d("refreshTokenEmpty", refreshToken.empty())
                .d("expiresInSeconds", expiresInSeconds));
        ACSDK_DEBUG(LX("handleLwaresponseFailed").d("body", body));
        return ;
      }

      ACSDK_DEBUG(LX("handleLwaResponseSucceeded")
            .d("refreshToken", refreshToken).d("authToken", authToken).d("expiresInSeconds", expiresInSeconds));

      std::cout << "authToken: " << authToken << std::endl;
      std::cout << "refreshToken: " << refreshToken << std::endl;

      std::cout << "get refresh Token and save to file" << std::endl;
      writeTokenToFile(refreshToken,clientId);
      return ;
   } else {
      std::string error;
      auto errorIterator = document.FindMember(JSON_KEY_ERROR.c_str());
      if (errorIterator != document.MemberEnd() && errorIterator->value.IsString()) {
         error = errorIterator->value.GetString();
      }
      if (!error.empty()) {
        // If `error` field is non-empty in the body, it means that we encountered an error.
       // ACSDK_ERROR(LX("handleLwaResponseFailed").d("error", error).d("isUnrecoverable", isUnrecoverable(error)));
        return ;
      } else {
         ACSDK_ERROR(LX("handleLwaResponseFailed").d("error", "errorNotFoundInResponseBody"));
         return ;
      }
   }
}

/**
 * read the code verifier from productdata.txt file
 * @param authCode    authorization code from component app
 * @param redirecturi redirect URI from component app
 * @param clientId    client ID from component app
 */
void WisAVS::readCodeVerifierFromFile(std::string& authCode,std::string& redirecturi,std::string& clientId){
  std::cout << "\t\tstart read code verifier from file" << std::endl;
  std::string fileName = STORE_ROOT_FOLDER + "productdata.txt";
  //  std::ifstream inputFile(fileName.c_str(), std::ifstream::binary);
  std::ifstream inputFile(fileName.c_str());
  if (!inputFile.good()) {
     std::cout << "Couldn't open audio file!" << std::endl;
     return;
  }
  inputFile.seekg(0, std::ios::end);
  int fileLengthInBytes = inputFile.tellg();
  std::cout << "file size: " << fileLengthInBytes << std::endl;
  char* file_buf = new char [fileLengthInBytes];
  inputFile.seekg(0, std::ios::beg);
  inputFile.read(file_buf,fileLengthInBytes);
  inputFile.close();
  file_buf[fileLengthInBytes]=0;
  std::string productData = file_buf;
  std::cout << "product data: " << productData << std::endl;

  std::string codeVerifier;
  char * strc = new char[strlen(productData.c_str())+1];
  strcpy(strc, productData.c_str());
  char* p = strtok(strc,":");
  while(p != NULL){
     std::cout << "content: " << p << std::endl;
     codeVerifier = p;
     p = strtok(NULL,":");
  }
  std::cout << "code verifier: " << codeVerifier << std::endl;

  useHttpPostGetToken(authCode,redirecturi,clientId,codeVerifier);

  delete file_buf;
  file_buf = 0;
  delete strc;
  strc = 0;
}

/**
* use authorization code information get access and refresh token
* @param authCode     authorizaiont code
* @param redirecturi  redirect URI
* @param clientId     client ID
* @param codeVerifier code verifier
*/
void WisAVS::useHttpPostGetToken(std::string& authCode,std::string& redirecturi,std::string& clientId,std::string& codeVerifier){
   std::cout << "\t\tstart use auth code get access token" << std::endl;
   m_httpPost = HttpPost::create();

   std::ostringstream postData;
   postData
     << "grant_type=" << "authorization_code"
     << "&code=" << authCode
     << "&redirect_uri=" << redirecturi
     << "&client_id=" << clientId
     << "&code_verifier=" << codeVerifier;

   std::cout << "post Data" << std::endl;
   std::string body;
   auto timeout = DEFAULT_REQUEST_TIMEOUT;

   auto code = m_httpPost->doPost(DEFAULT_LWA_URL, postData.str(), timeout, body);
   handleLwaResponse1(code, body,clientId);
}

void WisAVS::createVerifier(){
  std::string productId = "linux_avs";

  std::string baseContent="asdfghjklqwertyuiopzxcvbnmASDFGHJKLQWERTYUIOPZXCVBNM1234567890";
  std::cout << "base content size: " << baseContent.length() << std::endl;

  std::string codeverifier;
  // srand((int)time(0)); //设置随机数种子(second),确保每次产生随机数不一样
  srand((int)clock()); //设置随机数种子(milliseconds),确保每次产生随机数不一样
  for(int icnt = 0; icnt != 128; ++icnt){
     //codeverifier += baseContent[random(baseContent.length())];
     codeverifier += baseContent[rand()%baseContent.length()];
  }
  std::cout << "code verifier: " << codeverifier << ", size: " << codeverifier.length() << std::endl;

  std::string baseDsn = "1234567890zxcvbnmasdfghjklqwertyuiop";
  std::string dsn;
  for(int i = 0 ; i != 16; ++i){
     //dsn += baseDsn[random(baseDsn.length())];
     dsn += baseDsn[rand()%baseDsn.length()];
  }
  std::cout << "dsn: " << dsn << ", size: " << dsn.length() << std::endl;

  writeProductDataToFile(productId,dsn,codeverifier);
}

void WisAVS::readAuthCodeFromFile(){
  std::cout << "\t\tstart read auth code from file" << std::endl;
  std::string fileName = STORE_ROOT_FOLDER + "authcode.txt";
  std::ifstream inputFile(fileName.c_str(), std::ifstream::binary);
  //  std::ifstream inputFile(fileName.c_str());
  std::cout << "file name: "<<fileName << '\n';
  if (!inputFile.good()) {
     std::cout << "Couldn't open authcode.txt file!" << std::endl;
     return;
  }
  inputFile.seekg(0, std::ios::end);
  int fileLengthInBytes = inputFile.tellg();
  std::cout << "file size: " << fileLengthInBytes << std::endl;

  inputFile.seekg(0, std::ios::beg);

  std::string clientId;
  std::string redirecturi;
  std::string authcode;
  int index = 0;
  std::string line;
  while(getline(inputFile,line)){
     if(index==1){
        clientId=line;
     }else if(index==2){
        redirecturi=line;
     }else if(index==3){
        authcode=line;
     }else if(index == 0){
        std::cout << "line: " << line << std::endl;
     }
     index++;
  }
  inputFile.close();
  std::cout<<"client id: " << clientId << std::endl;
  std::cout<<"redirect uri: " <<redirecturi << std::endl;
  std::cout << "authCode: " << authcode << std::endl;
  readCodeVerifierFromFile(authcode,redirecturi,clientId);
}

void WisAVS::sendSettingsUpdatedEvent(std::string locale){
  if (!m_connectionManager) {
    return;
  }
  WisCommon avsWisCommon;
  std::string settingsUpdatedEvent = "{"                              \
      "\"event\": {"                                                \
          "\"header\": {"                                           \
              "\"namespace\": \"Settings\","                         \
              "\"name\": \"SettingsUpdated\","                        \
              "\"messageId\": \"messageId123\""                     \
          "},"                                                      \
          "\"payload\": {"                                          \
              "\"settings\": ["                                      \
                "{"                                                   \
                  "\"key\": \"locale\","                              \
                  "\"value\": \"localeValue\""                                \
                "}"                                                   \
              "]"                                                     \
          "}"                                                       \
      "}"                                                           \
  "}";

  std::string sendData;
  //sendData = avsWisCommon.replace_all(settingsUpdatedEvent,"localeValue", "en-US");
  sendData = avsWisCommon.replace_all(settingsUpdatedEvent,"localeValue", locale);

  std::string messageId = utils::uuidGeneration::generateUUID();
  sendData = avsWisCommon.replace_all(sendData,"messageId123",messageId);

  auto messageRequest = std::make_shared<ObservableMessageRequest>(sendData, nullptr);
  m_connectionManager->sendMessage(messageRequest);
}

void WisAVS::sendPlaybackControllerEvent(std::string context, std::string playbackAction){
  if (!m_connectionManager) {
    return;
  }
  WisCommon avsWisCommon;
  std::string playbackControllerEvent = ","                           \
      "\"event\": {"                                                  \
          "\"header\": {"                                             \
              "\"namespace\": \"PlaybackController\","                \
              "\"name\": \"playbackAction\","                         \
              "\"messageId\": \"messageId123\""                       \
          "},"                                                        \
          "\"payload\": {"                                            \
          "}"                                                         \
      "}"                                                              \
  "}";

  std::string sendDataEvent;
  if (playbackAction.compare("play") == 0) {  // equal to
      sendDataEvent = avsWisCommon.replace_all(playbackControllerEvent,"playbackAction", "PlayCommandIssued");
  } else if (playbackAction.compare("pause") == 0) {
      sendDataEvent = avsWisCommon.replace_all(playbackControllerEvent,"playbackAction", "PauseCommandIssued");
  } else if (playbackAction.compare("previous") == 0) {
      sendDataEvent = avsWisCommon.replace_all(playbackControllerEvent,"playbackAction", "PreviousCommandIssued");
  } else if (playbackAction.compare("next") == 0) {
      sendDataEvent = avsWisCommon.replace_all(playbackControllerEvent,"playbackAction", "NextCommandIssued");
  }

  std::string messageId = utils::uuidGeneration::generateUUID();
  sendDataEvent = avsWisCommon.replace_all(sendDataEvent,"messageId123",messageId);

  std::string sendData = context.substr(0, strlen(context.c_str()) - 1);
  sendData = sendData + sendDataEvent;

  auto messageRequest = std::make_shared<ObservableMessageRequest>(sendData, nullptr);
  m_connectionManager->sendMessage(messageRequest);
}
