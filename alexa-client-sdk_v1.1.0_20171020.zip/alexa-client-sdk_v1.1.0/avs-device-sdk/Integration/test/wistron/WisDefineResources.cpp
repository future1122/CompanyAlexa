
#include "WisDefineResources.h"

std::string configPath = STORE_ROOT_FOLDER + "refreshtoken.json";  // Bob update
std::string inputPath = APP_ROOT_FOLDER + "inputs"; // King update

std::string volumeChangedEvent = "{"                              \
    "\"event\": {"                                                \
        "\"header\": {"                                           \
            "\"namespace\": \"Speaker\","                         \
            "\"name\": \"VolumeChanged\","                        \
            "\"messageId\": \"messageId123\""                     \
        "},"                                                      \
        "\"payload\": {"                                          \
            "\"volume\": current_volume,"                         \
            "\"muted\": isMuted"                                  \
        "}"                                                       \
    "}"                                                           \
"}";

std::string muteChangedEvent = "{"                                \
    "\"event\": {"                                                \
        "\"header\": {"                                           \
            "\"namespace\": \"Speaker\","                         \
            "\"name\": \"MuteChanged\","                          \
            "\"messageId\": \"messageId123\""                     \
        "},"                                                      \
        "\"payload\": {"                                          \
            "\"volume\": current_volume,"                         \
            "\"muted\": isMuted"                                  \
        "}"                                                       \
    "}"                                                           \
"}";


const char* CMD_FIND_DEVICES          ="find_devices";
const char* CMD_PLAY_MUSIC            ="play_music";
const char* CMD_PLAY_LOCAL_MUSIC      ="play_local_music";
const char* CMD_WIFI_SETTING          ="wifi_setting";
const char* CMD_SVA_AVS               ="sva_avs";
const char* CMD_RESET_WIFI            ="reset_wifi";
const char* CMD_AVS_DATA              ="avs_data";
const char* CMD_AVS_AUTH_CODE         ="avs_auth_code";
const char* CMD_AVS_CLEAR             ="clear_avs_data";
const char* CMD_SET_LOCALE            ="locale";
const char* CMD_OTA_UPDATE            ="ota";
const char* CMD_ADVANCED_SETTING      ="advanced_settings";
//Bob add for FM 20170821
const char* CMD_FM_DATA                ="fm";
const char* CMD_FM_DATA_ENABLE         ="enable";
const char* CMD_FM_DATA_DISABLE        ="disable";
const char* CMD_FM_DATA_FREQUENCY      ="frequency";
const char* CMD_FM_DATA_GET_VOLUME     ="get_volume";
const char* CMD_FM_DATA_SET_VOLUME     ="set_volume";
const char* CMD_FM_DATA_SEARCH         ="search";
//Bob end 20170821
const std::string CMD_REBOOT_DEVICE = "reboot_device";
const char* CMD_BATTERY_INFO           ="battery_info";
