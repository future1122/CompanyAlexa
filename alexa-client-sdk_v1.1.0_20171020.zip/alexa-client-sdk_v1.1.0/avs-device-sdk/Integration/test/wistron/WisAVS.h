#include <iostream>
#include <sstream>
#include <random>
#include <rapidjson/document.h>
#include <rapidjson/error/en.h>
#include <unordered_map>
#include <stdio.h>

#include <string.h>
#include <sys/time.h>
#include <fstream>

#include <algorithm>
#include <chrono>
#include <condition_variable>
#include <memory>
#include <mutex>
#include <thread>
#include <gmock/gmock.h>
#include <gtest/gtest.h>

#include "AuthDelegate/AuthDelegate.h"
#include "AuthDelegate/HttpPost.h"
#include "AuthDelegate/HttpPostInterface.h"
#include "Integration/ObservableMessageRequest.h"
#include "AVSCommon/Utils/Logger/LogEntry.h"
#include "AVSCommon/Utils/UUIDGeneration/UUIDGeneration.h"
#include <AVSCommon/Utils/Logger/Logger.h>
#include <AVSCommon/Utils/Memory/Memory.h>
#include "ACL/AVSConnectionManager.h"
#include "ContextManager/ContextManager.h"
#include "AudioPlayer/AudioPlayer.h"
#include "AIP/AudioInputProcessor.h"

#include "WisDefineResources.h"

//Bob add for settings 20171019
#include <iterator>
#include <rapidjson/stringbuffer.h>
#include "AVSCommon/SDKInterfaces/GlobalSettingsObserverInterface.h"
#include "AVSCommon/SDKInterfaces/SingleSettingObserverInterface.h"
#include "Settings/Settings.h"
#include "Settings/SettingsUpdatedEventSender.h"
#include "Settings/SettingsStorageInterface.h"
#include "Settings/SQLiteSettingStorage.h"
//Bob end 20171019

//Bob add for PlaybackController 20171020
#include <AVSCommon/AVS/MessageRequest.h>
#include <AVSCommon/Utils/JSON/JSONUtils.h>
#include "PlaybackController/PlaybackController.h"
//Bob end 20171020

using namespace alexaClientSDK::capabilityAgents::aip;  // Bob add
using namespace alexaClientSDK::acl;
using namespace alexaClientSDK::avsCommon;
using namespace alexaClientSDK::avsCommon::utils::uuidGeneration;
using namespace alexaClientSDK::avsCommon::avs;
using namespace alexaClientSDK::authDelegate;
using namespace alexaClientSDK::avsCommon::utils::memory;
using namespace alexaClientSDK::integration;
using namespace alexaClientSDK::contextManager;
using namespace alexaClientSDK::capabilityAgents::audioPlayer;
using namespace ::testing;
//Bob add for settings 20171019
using namespace alexaClientSDK::capabilityAgents::settings;
//Bob end 20171019
//Bob add for PlaybackController 20171020
using namespace alexaClientSDK::capabilityAgents::playbackController;
//Bob end 20171020

static const std::string TAG_WisAVS("WisAVS");
#define LX(event) alexaClientSDK::avsCommon::utils::logger::LogEntry(TAG_WisAVS, event)

static const std::string DEFAULT_LWA_URL = "https://api.amazon.com/auth/O2/token";
static const std::chrono::minutes DEFAULT_REQUEST_TIMEOUT = std::chrono::minutes(5);
/// This is the property name in the JSON which refers to the access token.
static const std::string JSON_KEY_ACCESS_TOKEN = "access_token";
/// This is the property name in the JSON which refers to the refresh token.
static const std::string JSON_KEY_REFRESH_TOKEN = "refresh_token";
/// This is the property name in the JSON which refers to the expiration time.
static const std::string JSON_KEY_EXPIRES_IN = "expires_in";
/// This is the property name in the JSON which refers to the error.
static const std::string JSON_KEY_ERROR = "error";

class WisAVS {
private:
    void writeProductDataToFile(std::string& productId,std::string& dsn,std::string& verifier);
    void readCodeVerifierFromFile(std::string& authCode,std::string& redirecturi,std::string& clientId);
    void useHttpPostGetToken(std::string& authCode,std::string& redirecturi,std::string& clientId,std::string& codeVerifier);
    void handleLwaResponse1(long code, const std::string& body,std::string& clientId);
    void writeTokenToFile(std::string& refreshToken,std::string& clientId);

    std::shared_ptr<HttpPost> m_httpPost;
public:
    void createVerifier();
    void readAuthCodeFromFile();
    void sendSettingsUpdatedEvent(std::string locale);
    void sendPlaybackControllerEvent(std::string context, std::string playbackAction);

    std::shared_ptr<AVSConnectionManager> m_connectionManager;  // King add
    std::shared_ptr<ContextManager> m_contextManager;
    std::shared_ptr<AudioPlayer> m_audioPlayer;
    std::shared_ptr<AudioInputProcessor> m_AudioInputProcessor; //Bob add
    /// The @c Settings Object to test.
    std::shared_ptr<Settings> m_settingsObject; //Bob add for settings 20171020

    /// PlaybackController instance.
    std::shared_ptr<PlaybackController> m_playbackController; //Bob add for PlaybackController 20171020
};
