#include <memory>

#include "ContextManager/ContextManager.h"

using namespace alexaClientSDK::avsCommon;
using namespace alexaClientSDK::avsCommon::avs;
using namespace alexaClientSDK::avsCommon::sdkInterfaces;
using namespace alexaClientSDK::contextManager;

/**
 * @c MockContextRequester used to verify @c ContextManager behavior.
 */
class MockContextRequester : public ContextRequesterInterface {
public:
    /**
     * Creates an instance of the @c MockContextRequester.
     *
     * @param contextManager Pointer to an instance of the @c ContextManager.
     * @return A shared pointer to an instance of the @c MockContextRequester.
     */
    static std::shared_ptr<MockContextRequester> create(std::shared_ptr<ContextManager> contextManager);

    /**
     * Constructor
     *
     * @param contextManager Pointer to an instance of the @c ContextManager.
     */
    MockContextRequester(std::shared_ptr<ContextManager> contextManager);

    ~MockContextRequester();

    void onContextAvailable(const std::string& context) override;

    void onContextFailure(const ContextRequestError error) override;

    /**
     * Waits for a specified time for the context to be available @c getContext.
     *
     * @param duration Number of milliseconds to wait before giving up.
     * @return @c true if a context or failure was received within the specified duration, else @c false.
     */
    bool waitForContext(const std::chrono::milliseconds duration = std::chrono::milliseconds(200));

    /**
     * Waits for a specified time for the context request to fail on a @c getContext.
     *
     * @param duration Number of milliseconds to wait before giving up.
     * @return @c true if a failure was received within the specified duration, else @c false.
     */
    bool waitForFailure(const std::chrono::milliseconds duration = std::chrono::milliseconds(200));

    /**
     * Function to read the stored context.
     *
     * @return The context.
     */
    std::string& getContextString();

private:
    /// Instance of @ ContextManager
    std::shared_ptr<ContextManager> m_contextManager;

    /// Condition variable to wake the @ waitForContext.
    std::condition_variable m_wakeTriggerSuccess;

    /// Condition variable to wake the @ waitForFailure.
    std::condition_variable m_wakeTriggerFailure;

    /// mutex to protect @c m_contextAvailable.
    std::mutex m_mutexSuccess;

    /// mutex to protect @c m_contextFailure.
    std::mutex m_mutexFailure;

    /// Flag to indicate context is available.
    bool m_contextAvailable;

    /// Flag to indicate there was a failure during @c getContext.
    bool m_contextFailure;

    /// String to hold the context returned by the @c ContextManager.
    std::string m_context;
};
