
class WisDeviceScanFun
{
public:
    void start();
private:
    int receiveCommand();// Kernal
};
