
#include "ContextManager/ContextManager.h"

using namespace alexaClientSDK::avsCommon;
using namespace alexaClientSDK::avsCommon::avs;
using namespace alexaClientSDK::avsCommon::sdkInterfaces;
using namespace alexaClientSDK::contextManager;



/**
 * @c MockStateProvider used to verify @c ContextManager behavior.
 */
class MockStateProvider : public StateProviderInterface {
public:
    /**
     * Creates an instance of the @c MockStateProvider.
     *
     * @param contextManager Pointer to an instance of the @c ContextManager.
     * @param namespaceAndName The namespace and name of the @c StateProvider.
     * @param jsonState The state of the @c StateProvider set in response to the @c provideState.
     * @param refreshPolicy The refresh policy for the state set in response to the @c provideState.
     * @param delayTime The time @c m_doProvideThread sleeps before updating state via @c setState.
     * @return A pointer to an instance of the @c MockStateProvider.
     */
    static std::shared_ptr<MockStateProvider> create(
            std::shared_ptr<ContextManager> contextManager, const NamespaceAndName& namespaceAndName,
            const std::string& state, const StateRefreshPolicy& refreshPolicy, const std::chrono::milliseconds delayTime);

    /**
     * Constructor. It sets up the state and refresh policy that needs to be sent in response to a @c provideContext
     * request.
     *
     * @param contextManager Pointer to an instance of the @c ContextManager.
     * @param namespaceAndName The namespace and name of the @c StateProvider.
     * @param jsonState The state of the @c StateProvider set in response to the @c provideState.
     * @param refreshPolicy The refresh policy for the state set in response to the @c provideState.
     * @param delayTime The time @c m_doProvideThread sleeps before updating state via @c setState.
     * @return A pointer to an instance of the @c MockStateProvider.
     */
    MockStateProvider(std::shared_ptr<ContextManager> contextManager,
            const NamespaceAndName& namespaceAndName, const std::string& state,
            const StateRefreshPolicy& refreshPolicy, const std::chrono::milliseconds delayTime);

    ~MockStateProvider();

    void provideState(unsigned int currentstateRequestToken) override;

    /**
     * Method for m_doProvideThread. It waits for @c m_delayTime and then calls @c setState with the state @c m_state
     * and the refresh policy @c m_refreshPolicy the @c stateProviderInterface was initialized with.
     */
    void doProvideState();

    unsigned int getCurrentstateRequestToken();

private:
    /// Pointer to an instance of the @c ContextManager
    std::shared_ptr<ContextManager> m_contextManager;

    /// The namespace and name of the @c stateProviderInterface
    NamespaceAndName m_namespaceAndName;

    /// The state provided to the @c ContextManager via @c setState.
    std::string m_state;

    /// The refresh policy for the state provided to the @c ContextManager via @c setState.
    StateRefreshPolicy m_refreshPolicy;

    /// The token provided by the @c ContextManager.
    unsigned int m_stateRequestToken;

    /// Thread to execute the doProvide.
    std::thread m_doProvideThread;

    /// Mutex to protect the @c m_provideState.
    std::mutex m_providerMutex;

    /// The condition variable used to wake up @c m_doProvideThread when the @c ContextManager requests for state.
    std::condition_variable m_providerWakeTrigger;

    /// The time the @c m_doProvideThread sleeps before providing state.
    std::chrono::milliseconds m_delayTime;

    /// Flag to indicate when a @c provideState has been called.
    bool m_provideState;

    /// Flag to indicate when the @c MockStateProvider is shutting down. When set, @c m_doProvideThread needs to return.
    bool m_stateProviderShutdown;
};
