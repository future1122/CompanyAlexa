#include "LocalMediaPlayer.h"

void LocalMediaPlayer::SetUp() {
    m_playerObserver = std::make_shared<MockPlayerObserver>();
    m_mediaPlayer = MediaPlayer::create();
    if(m_mediaPlayer) {
      m_mediaPlayer->setObserver(m_playerObserver);
    }
}

void LocalMediaPlayer::setMediaPlayerSource(std::string audioFilePath, int iterations, std::vector<size_t> receiveSizes) {
    m_audioFilePath = audioFilePath;
    if(MediaPlayerStatus::FAILURE != m_mediaPlayer->setSource(
            std::unique_ptr<AttachmentReader>(new MockAttachmentReader(audioFilePath, iterations, receiveSizes)))){
        printf("LocalMediaPlayer setSource success\n");
    }else{
        printf("LocalMediaPlayer setSource fail\n");
    }
}

void LocalMediaPlayer::setIStreamSource(std::string audioFilePath, bool repeat){
  m_audioFilePath = audioFilePath;
  if(MediaPlayerStatus::FAILURE != m_mediaPlayer->setSource(make_unique<std::ifstream>(audioFilePath), repeat)){
      printf("LocalMediaPlayer setIStreamSource success\n");
  }else{
      printf("LocalMediaPlayer setIStreamSource fail\n");
  }
}

std::string LocalMediaPlayer::getAudioFilePath(){
   return m_audioFilePath;
}
