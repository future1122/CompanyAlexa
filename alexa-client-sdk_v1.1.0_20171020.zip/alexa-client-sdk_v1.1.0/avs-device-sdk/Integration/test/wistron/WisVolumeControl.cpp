#include "WisVolumeControl.h"
#include "WisDefineResources.h"

void WisVolumeControl::sleep_ms(unsigned int secs){
    struct timeval tval;
    tval.tv_sec=secs/1000;
    tval.tv_usec=(secs*1000)%1000000;
    select(0,NULL,NULL,NULL,&tval);
}

/**
 * read the volume value
 * @return the backup volume value
 */
int WisVolumeControl::readVolumeValueFromFile(){
  int volume = 10;
   vcWisCommon.sysLocalTime("\t\tstart read volume value from file");
   std::string fileName = STORE_ROOT_FOLDER + "volume.txt";
   std::ifstream inputFile(fileName.c_str(), std::ifstream::binary);
   //  std::ifstream inputFile(fileName.c_str());
   std::cout << "file name: "<<fileName << '\n';
   if (!inputFile.good()) {
      vcWisCommon.sysLocalTime("Couldn't open volume.txt file and use default volume value:10");
      return volume;
   }
   inputFile.seekg(0, std::ios::end);
   inputFile.tellg();
   inputFile.seekg(0, std::ios::beg);

   std::string value="10"; //default value
   std::string line;
   while(getline(inputFile,line)){
      value = line;
   }
   inputFile.close();
   vcWisCommon.sysLocalTime(("read volume value from volume.txt file: "+value).c_str());
   return atoi(value.c_str());
}

/**
 * get the product current volume value
 */
void WisVolumeControl::getProductVolume(){
  std::string command ="volume_control get";
  system(command.c_str());
}

/**
 * get the mute value: true is mute ,otherwise is unmute
 * @param  value the payload value from directive
 * @return       the mute value
 */
bool WisVolumeControl::getVolumeMute(std::string value){
  bool isMute = false;
  std::size_t length = value.length();
  std::size_t pos = value.find(":");
  std::cout << "volume index: "<< pos <<", " << length << '\n';
  std::string str = value.substr (pos+1,length-pos-2);
  std::istringstream(str) >> std::boolalpha >> isMute;
  return isMute;
}

/**
 * get the volume value from payload
 * @param  value [the payload value from directive]
 * @return       [the volume value]
 */
int WisVolumeControl::getVolumeValue(std::string value){
  std::size_t length = value.length();
  std::size_t pos = value.find(":");
  std::cout << "volume index: "<< pos <<", " << length << '\n';
  std::string str = value.substr (pos+1,length-pos-2);
  int volume = atoi(str.data());
  return volume;
}

/**
 * [receive the set volume directives from AVS and set product volume]
 * @param value [the payload value from directives]
 */
void WisVolumeControl::setVolume(std::string value){
  vcWisCommon.sysLocalTime(("Start set Product Volume: "+value).c_str());
  int volume = getVolumeValue(value);
  vcWisCommon.sysLocalTime(("volume value: "+std::to_string(volume)).c_str());

  int setVolume = volume / 100.0 * VOLUME_LEVEL;
  vcWisCommon.sysLocalTime(("Will set Volume to: "+std::to_string(setVolume)).c_str());

  std::string command = "volume_control set "+std::to_string(setVolume);
  //use volume_control.sh set the product volume
  system(command.c_str());
  getProductVolume();

  system(("rm "+ STORE_CURRENT_VOLUME_FILE_PATH).c_str());
}

/**
 * [receive adjust volume directives from AVS and set product volume]
 * @param value [the payload value from directives]
 */
void WisVolumeControl::adjustVolume(std::string value){
    vcWisCommon.sysLocalTime(("Start adjust Product Volume: "+value).c_str());
    int volume = getVolumeValue(value);
    vcWisCommon.sysLocalTime(("volume value: "+std::to_string(volume)).c_str());
    std::string command;
    if(volume > 0){
      //add volume
      command = "volume_control set +";
    }else {
      //reduce volume
      command = "volume_control set -";
    }
    //use volume_control.sh set the product volume
    system(command.c_str());
    getProductVolume();

    system(("rm "+ STORE_CURRENT_VOLUME_FILE_PATH).c_str());
}

/**
 * receive set mute Directives from AVS and set product mute or unmute
 * @param value [the payload value from Directives]
 */
void WisVolumeControl::setMuteOrUnmute(std::string value){
    vcWisCommon.sysLocalTime(("Start set product mute or unmute: "+value).c_str());
    bool isMute = getVolumeMute(value);
    vcWisCommon.sysLocalTime(("Mute value: "+std::to_string(isMute)).c_str());
    if(isMute){
      if (!access(STORE_CURRENT_VOLUME_FILE_PATH.c_str(),F_OK) != -1) {  // File exist
        //save the current volume to STORE_CURRENT_VOLUME_FILE_PATH file
        system(("volume_control get > " + STORE_CURRENT_VOLUME_FILE_PATH).c_str());
        //set product mute
        system("volume_control set 0");
      }
    }else {
      //set product unmute
      /*int volume = readVolumeValueFromFile();
      std::string tmp = "the volume value "+ std::to_string(volume) + " before set mute";
      vcWisCommon.sysLocalTime(tmp.c_str());
      std::string command = "volume_control set "+std::to_string(volume);
      //use volume_control.sh set the product volume
      system(command.c_str());*/
      //set product unmute
      int volume = readVolumeValueFromFile();
      if (volume > VOLUME_LEVEL) {
        volume = VOLUME_LEVEL;
      }
      std::string tmp = "the volume value "+ std::to_string(volume) + " before set mute";
      printf("%s\n",tmp.c_str());
      std::string command = "volume_control set "+std::to_string(volume);
      //use volume_control.sh set the product volume
      system(command.c_str());

      system(("rm "+ STORE_CURRENT_VOLUME_FILE_PATH).c_str());
    }
    getProductVolume();
}
