#include "MockPlayerObserver.h"

void MockPlayerObserver::onPlaybackStarted() {
    std::lock_guard<std::mutex> lock(m_mutex);
    m_playbackStarted = true;
    m_playbackFinished = false;
    m_wakePlaybackStarted.notify_all();
    m_onPlaybackStartedCallCount++;
}

void MockPlayerObserver::onPlaybackFinished() {
    std::lock_guard<std::mutex> lock(m_mutex);
    m_playbackFinished = true;
    m_playbackStarted = false;
    m_wakePlaybackFinished.notify_all();
    m_onPlaybackFinishedCallCount++;
}

void MockPlayerObserver::onPlaybackError(const ErrorType& type, std::string error) {
    ACSDK_ERROR(LX_MockPlayerObserver("onPlaybackError").d("type", type).d("error", error));
};

void MockPlayerObserver::onPlaybackPaused() {
    std::lock_guard<std::mutex> lock(m_mutex);
    m_playbackPaused = true;
    m_wakePlaybackPaused.notify_all();
};

void MockPlayerObserver::onPlaybackResumed() {
    std::lock_guard<std::mutex> lock(m_mutex);
    m_playbackResumed = true;
    m_playbackPaused = false;
    m_wakePlaybackResumed.notify_all();
};

bool MockPlayerObserver::waitForPlaybackStarted(const std::chrono::milliseconds duration) {
    std::unique_lock<std::mutex> lock(m_mutex);
    if (!m_wakePlaybackStarted.wait_for(lock, duration, [this]() { return m_playbackStarted; })) {
        return false;
    }
    return true;
}

bool MockPlayerObserver::waitForPlaybackFinished(const std::chrono::milliseconds duration) {
    std::unique_lock<std::mutex> lock(m_mutex);
    if (!m_wakePlaybackFinished.wait_for(lock, duration, [this]() { return m_playbackFinished; })) {
        return false;
    }
    return true;
}

bool MockPlayerObserver::waitForPlaybackPaused(const std::chrono::milliseconds duration) {
    std::unique_lock<std::mutex> lock(m_mutex);
    if (!m_wakePlaybackPaused.wait_for(lock, duration, [this]() { return m_playbackPaused; })) {
        return false;
    }
    return true;
}

bool MockPlayerObserver::waitForPlaybackResumed(const std::chrono::milliseconds duration) {
    std::unique_lock<std::mutex> lock(m_mutex);
    if (!m_wakePlaybackResumed.wait_for(lock, duration, [this]() { return m_playbackResumed; })) {
        return false;
    }
    return true;
}

int MockPlayerObserver::getOnPlaybackStartedCallCount() {
    return m_onPlaybackStartedCallCount;
}

int MockPlayerObserver::getOnPlaybackFinishedCallCount() {
    return m_onPlaybackFinishedCallCount;
}
