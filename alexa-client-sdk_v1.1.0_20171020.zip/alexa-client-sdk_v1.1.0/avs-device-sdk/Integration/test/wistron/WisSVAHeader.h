// King add start: sva
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/time.h>
#include <dirent.h>
#include <errno.h>
#include <unistd.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <cutils/atomic.h>
#include <pthread.h>

#include "qsthw_api.h"
#include "qsthw_defs.h"

#define SVA_STATUS_OK 0
#define MAX_SOUND_TRIGGER_SESSIONS 8
#define SM_FILE_PATH_MAX_LENGTH 128
#define MIN_REQ_PARAMS_PER_SESSION 3
#define SM_MINOR_VERSION 1

#define SOUNDTRIGGER_TEST_USAGE \
    "qti_sound_trigger_test [OPTIONS]\n" \
    "Example: sound_trigger_test -ns 1 -id 1 -sm /data/HS.uim -nk 1\n" \
    "OPTIONS:\n" \
    "-ns number of sessions\n" \
    "-id session id\n" \
    "-vendor_uuid vendor uuid for the session\n" \
    "-sm soundmodel file\n" \
    "-nk number of keywords\n" \
    "-kwcnf list of keyword confidence levels. valid with -nk\n" \
    " valid Confidence value [1 100]. Default is 60." \
    "-nu number of users per keyword.\n" \
    "-usrcnf list of user confidence levels. Valid with -nu\n" \
    " valid Confidence value [1 100]. Default is 60.\n" \
    "-user enable user identification; true or false. Default is false.\n" \
    "-lab LookAheadBuffering. Default is false.\n" \
    "-lab_duration duration of capture data after detection event. Disabled by default.\n" \
    "-kb KeywordBuffering. Default is false.\n" \
    "-kb_duration duration of keyword for detection in milliseconds. Disabled by default. \n" \
    "-----------------------------------------------------------\n" \
    "USAGE:\n"  \
    "each session specific data to be given in below format and order\n" \
    "id is Unique(> 0) and should be present at start of each session data\n" \
    "It is also used to identify session for later commands\n" \
    "-nu value is relevant only if user verification is enabled\n" \
    "-vendor_uuid should be valid unique vendor uuid.\n"\
    "In case of no values entered, default value for number of users\n" \
    "and vendor uuid i.e. 0 and sva vendor uuid is assumed\n" \
    "-----------------------------------------------------------\n" \
    "Enter per session params for all the sessions at the start after -ns\n" \
    "-nu and -vendor_uuid are optional per session\n" \
    "sound_trigger_test -ns <number of sessions\n" \
    "-id <session id> -sm <soundmodel> -nk <number of keywords>\n" \
    "-nu <number of users per keyword> -vendor_uuid <vendor uuid>\n" \
    "-----------------------------------------------------------\n" \
    "Optional params to be given after all session specific data is entered\n" \
    "LAB set to disable with KeywordBuffering enabled is treated as an invalid case\n" \
    "-user <user verification>\n" \
    "-lab <LookAheadBuffering enable/disable> -lab_duration <LAB duration in seconds>\n" \
    "-kb <KeywordBuffering enable/disable> -kb_duration <KeywordBuffering duration in milliseconds>\n" \
    "-kwcnf <keyword confidence levels> -usrcnf <user confidence levels>\n"

struct sm_session_data {
    int session_id;
    sound_trigger_uuid_t vendor_uuid;
    char sm_file_path[SM_FILE_PATH_MAX_LENGTH];
    sound_model_handle_t sm_handle;
    unsigned int num_kws;
    unsigned int num_users;
    bool loaded;
    bool started;
    unsigned int counter;
    struct sound_trigger_recognition_config rc_config;
    struct qsthw_phrase_recognition_event qsthw_event;
};

struct keyword_buffer_config {
    int version;
    uint32_t kb_duration;
}__packed;

const qsthw_module_handle_t *st_mod_handle;
sound_model_handle_t sm_handle;
struct sound_trigger_recognition_config *rc_config;
static struct sm_session_data sound_trigger_info[MAX_SOUND_TRIGGER_SESSIONS];
static int num_sessions;
static int lab_duration = 5; //5sec is default duration
static int kb_duration_ms = 2000; //2000 msec is default duration
int total_duration_ms = 0;
// King debug
bool isSVADetected = false;
bool isCaptureLABData = false;

struct qsthw_phrase_recognition_event *qsthw_event_cache;

/* SVA vendor uuid */
static const sound_trigger_uuid_t qc_uuid =
    { 0x68ab2d40, 0xe860, 0x11e3, 0x95ef, { 0x00, 0x02, 0xa5, 0xd5, 0xc5, 0x1b } };

#define MAX_SET_PARAM_KEYS 3
static const char *set_param_key_array[] =
{
     "st_custom_channel_mixing",
     "st_session_pause",
     "st_bad_mic_channel_index"
};
// King add end: SVA
